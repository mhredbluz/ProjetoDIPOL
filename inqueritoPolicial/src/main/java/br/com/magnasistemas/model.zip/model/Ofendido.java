package br.com.magnasistemas.model;

import javax.persistence.Entity;

@Entity
public class Ofendido extends Pessoa{
	
	
}
